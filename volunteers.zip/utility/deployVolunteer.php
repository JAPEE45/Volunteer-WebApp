<?php
include_once 'db.php';
include 'sendSms.php';

// Read raw JSON body
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['volunteerId']) || !isset($data['eventId'])) {
    echo json_encode(["error" => "Invalid or missing data"]);
    exit;
}

$volunteerId = $data['volunteerId'];
$eventId = $data['eventId'];

// Insert into deployment table
$stmt = $conn->prepare("INSERT INTO deployment (user_id, event_id) VALUES (?, ?)");
$stmt->bind_param("ii", $volunteerId, $eventId);

if ($stmt->execute()) {
    // Update user status to 'deployed'
    $updateStmt = $conn->prepare("UPDATE users SET status = 'deployed' WHERE id = ?");
    $updateStmt->bind_param("i", $volunteerId);
    $updateStmt->execute();
    $updateStmt->close();
    $dinfo = $conn->prepare("
        SELECT 
            u.fullName, 
            u.mobile, 
            e.location, 
            e.date, 
            e.eventName 
        FROM 
            deployment d
        JOIN 
            users u ON d.user_id = u.id
        JOIN 
            events e ON d.event_id = e.id
        WHERE 
            d.user_id = ? AND d.event_id = ?
    ");
    $dinfo->bind_param("ii", $volunteerId, $eventId);
    $dinfo->execute();
    $dinfoRes = $dinfo->get_result();
    $res = $dinfoRes->fetch_assoc();
    $dinfo->close();

    if ($res) {
        $mobile = $res['mobile'];
        $content = "Hi {$res['fullName']}, Thank you for confirming your availability! You are now officially deployed for the following:
Location: {$res['location']}
Date: {$res['date']}
Event: {$res['eventName']}

Please bring your Red Cross ID and arrive on time. Stay safe and thank you for your service.";

        sendMessage($mobile, $content);
    }

    

    echo json_encode(["success" => true, "message" => "Volunteer deployed successfully"]);
} else {
    echo json_encode(["success" => false, "error" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
