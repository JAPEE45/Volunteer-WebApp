<?php
include_once 'db.php';

$sql = "
SELECT 
    u.id,
    u.fullName,
    u.account_status,
    u.status,
    u.age,
    u.address,
    u.mobile,
    e.location AS deployedLocation,
    e.eventName
FROM users u
LEFT JOIN (
    SELECT d.user_id, d.event_id
    FROM deployment d
    WHERE d.createdAt = (
        SELECT MAX(d2.createdAt)
        FROM deployment d2
        WHERE d2.user_id = d.user_id
    )
    LIMIT 1
) latest_deployment ON latest_deployment.user_id = u.id
LEFT JOIN events e ON latest_deployment.event_id = e.id
WHERE u.user_type = 'volunteer'
GROUP BY u.id;

";

$result = $conn->query($sql);

if (!$result) {
    echo json_encode(["error" => $conn->error]);
    exit;
}

$volunteers = $result->fetch_all(MYSQLI_ASSOC);

header('Content-Type: application/json');
echo json_encode($volunteers);

$conn->close();
?>
